sub init()
  m.top.setFocus(true)
  setVideo()
end sub

function setVideo() as void
  videoContent = createObject("RoSGNode", "ContentNode")
  videoContent.url = "http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8"
  videoContent.title = "Test Video"
  videoContent.streamformat = "hls"

  m.video = m.top.findNode("videoPlayer")
  m.video.content = videoContent
  m.video.control = "play"
end function


function onKeyEvent(key as String, press as Boolean) as Boolean
    handled = false

    if press
        if key = "back" and m.video.control = "play"
            m.video.control = "stop"
            'don't set handle to true yet so we also navigate back to previous screen
        end if
    end if

    return handled
end function