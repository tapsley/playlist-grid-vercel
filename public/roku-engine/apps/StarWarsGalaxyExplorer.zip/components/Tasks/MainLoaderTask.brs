sub Init()
    m.top.functionName = "GetCategoryContent"
end sub

sub GetCategoryContent()
    
    m.next = true
    contentNode = CreateObject("roSGNode", "ContentNode")
    url = "https://swapi.dev/api/" + m.top.category + "/?" + "page=1&search=" + m.top.input + "&format=json"
    
    while m.next<>false       
        xfer = CreateObject("roURLTransfer")
        xfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
        xfer.SetURL(url)
        rsp = xfer.GetToString()

        json = ParseJson(rsp)
        if json <> invalid

            value = json.Lookup("results")
            if Type(value) = "roArray" ' if parsed key value having other objects in it       
                for each item in value ' parse items and add them to contentNode
                    itemData = GetItemData(item)
                    itemContent = contentNode.createChild("ContentNode")
                    itemContent.setFields(itemData)
                end for
            end if

            if json.Lookup("next") <> invalid then
                url = json.Lookup("next")
                m.next = true
            else
                m.next = false
            end if
        else
            m.next = false
        end if
    end while

    ' populate content field with root content node.
    m.top.content = contentNode
        
end sub


function GetItemData(starwar as Object) as Object
    item = {}
    if m.top.category = "people"
        item.hdgridposterurl = "pkg:/images/People_Icon.jpg"
        item.hdposterurl = "pkg:/images/People_Icon.jpg"
    else if m.top.category = "planets"
        item.hdgridposterurl = "pkg:/images/Planet_Icon.jpg"
        item.hdposterurl = "pkg:/images/Planet_Icon.jpg"
    else if m.top.category = "starships"
        item.hdgridposterurl = "pkg:/images/Starships_Icon.jpg"
        item.hdposterurl = "pkg:/images/Starships_Icon.jpg"
    else
        item.hdgridposterurl = "pkg:/images/StarWars_Icon.jpg"
        item.hdposterurl = "pkg:/images/StarWars_Icon.jpg"
    end if
    item.shortdescriptionline1 = starwar.name
    item.shortdescriptionline2 = starwar.url
    return item
end function